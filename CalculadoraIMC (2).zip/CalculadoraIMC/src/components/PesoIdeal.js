import React from 'react';
import { Text, StyleSheet } from 'react-native';

const PesoIdeal = ({ altura }) => {
  // Validação de altura
  if (!altura || altura <= 0) return null; // Não renderiza se altura for inválida
  
  // Converte altura para metros
  const alturaEmMetros = altura > 3 ? altura / 100 : altura;
  
  // Calcula peso ideal mínimo e máximo com base no IMC (18.5 a 24.9)
  const pesoMinimo = (18.5 * alturaEmMetros * alturaEmMetros).toFixed(1);
  const pesoMaximo = (24.9 * alturaEmMetros * alturaEmMetros).toFixed(1);

  return (
    <>
      <Text style={styles.textoPeso}>
        Peso ideal mínimo: {pesoMinimo} kg 
      </Text>
      <Text style={styles.textoPeso}>
        Peso ideal máximo: {pesoMaximo} kg 
      </Text>
    </>
  );
};

// Estilos do texto
const styles = StyleSheet.create({
  textoPeso: {
    fontSize: 16, // Tamanho da fonte
    textAlign: 'center', // Centralizado
    color: '#666', // Cor do texto
    marginTop: 8, // Espaço acima
  },
});

export default PesoIdeal;