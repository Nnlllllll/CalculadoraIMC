import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text } from 'react-native';
import Resultado from './Result';
import Classificacao from './Classificação';
import PesoIdeal from './PesoIdeal';

const FormularioIMC = () => {
  const [peso, setPeso] = useState(''); // Estado para o peso
  const [altura, setAltura] = useState(''); // Estado para a altura
  const [imc, setImc] = useState(null); // Estado para o IMC
  const [mensagemErro, setMensagemErro] = useState(''); // Estado para a mensagem de erro

  const calcularIMC = () => {
    console.log('Botão pressionado'); // Confirma que o botão foi clicado
    console.log('Peso:', peso, 'Altura:', altura); // Mostra os valores atuais

    // Limpa a mensagem de erro inicialmente
    setMensagemErro('');
    console.log('Mensagem de erro limpa');

    // Verifica se os campos estão vazios
    if (!peso || !altura) {
      setMensagemErro('Preencha todos os campos!');
      console.log('Erro: Campos vazios');
      return;
    }

    // Converte as entradas para números
    const pesoNum = parseFloat(peso.replace(',', '.'));
    const alturaNum = parseFloat(altura.replace(',', '.'));

    console.log('Peso convertido:', pesoNum, 'Altura convertida:', alturaNum);

    // Valida o peso
    if (isNaN(pesoNum)) {
      setMensagemErro('Peso deve ser um número válido!');
      console.log('Erro: Peso inválido');
      return;
    }

    // Valida a altura
    if (isNaN(alturaNum)) {
      setMensagemErro('Altura deve ser um número válido!');
      console.log('Erro: Altura inválida');
      return;
    }

    // Valida valores maiores que zero
    if (pesoNum <= 0 || alturaNum <= 0) {
      setMensagemErro('Valores devem ser maiores que zero!');
      console.log('Erro: Valores <= 0');
      return;
    }

    // Valida limites superiores
    if (pesoNum > 500) {
      setMensagemErro('Peso deve ser menor que 500 kg!');
      console.log('Erro: Peso > 500');
      return;
    }
    if (alturaNum > 300) {
      setMensagemErro('Altura deve ser menor que 300 cm!');
      console.log('Erro: Altura > 300');
      return;
    }

    // Calcula o IMC
    const alturaEmMetros = alturaNum > 3 ? alturaNum / 100 : alturaNum;
    const imcCalculado = (pesoNum / (alturaEmMetros * alturaEmMetros)).toFixed(1);

    console.log('IMC calculado:', imcCalculado);
    setImc(imcCalculado); // Atualiza o IMC
    setMensagemErro(''); // Remove a mensagem de erro
    console.log('Cálculo concluído, erro removido');
  };

  // Aqui é onde o return deve ser colocado
  return (
    <View style={styles.contêiner}>
      <TextInput
        style={styles.entrada}
        placeholder="Peso (kg)"
        keyboardType="numeric"
        value={peso}
        onChangeText={setPeso}
      />
      <TextInput
        style={styles.entrada}
        placeholder="Altura (cm)"
        keyboardType="numeric"
        value={altura}
        onChangeText={setAltura}
      />
      <Button 
        title="Calcular IMC" 
        onPress={calcularIMC} 
        testID="botaoCalcular" 
      />
      
      
      <Text style={styles.textoErro}>{mensagemErro || ' '}</Text>

      {imc !== null && (
        <View style={styles.contêinerResultados}>
          <Resultado imc={imc} />
          <Classificacao imc={parseFloat(imc)} />
          <PesoIdeal altura={parseFloat(altura)} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  contêiner: {
    padding: 16,
  },
  entrada: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  contêinerResultados: {
    marginTop: 20,
  },
  textoErro: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
});

export default FormularioIMC;