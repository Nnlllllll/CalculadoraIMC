import React from 'react';
import { Text, StyleSheet } from 'react-native';

const Resultado = ({ imc }) => {
    return(
        <Text style={styles.resultado}>Seu IMC é: {imc}</Text> // Exibe o valor do IMC
    );
};

// Estilos do resultado
const styles = StyleSheet.create({
    resultado: {
        marginTop: 20, // Espaço acima
        fontSize: 24, // Tamanho da fonte
        textAlign: 'center', // Centralizado
        color: '#666', // Cor do texto
    },
});

export default Resultado;