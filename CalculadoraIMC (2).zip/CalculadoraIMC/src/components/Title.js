import { Text, StyleSheet } from 'react-native';

const Titulo = () => {
    return (
        <Text style={styles.titulo}>Calculadora de IMC</Text> // Exibe o título
    );
};

// Estilos do título
const styles = StyleSheet.create({
    titulo: {
        fontSize: 32, // Tamanho da fonte
        fontWeight: 'bold', // Negrito
        textAlign: 'center', // Centralizado
        marginBottom: 24, // Espaço abaixo do título
    },
});

export default Titulo;