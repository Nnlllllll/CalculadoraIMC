import { StyleSheet, Text, View } from 'react-native';
import Titulo from './src/components/Title.js'; // Importa o componente Titulo
import FormularioIMC from './src/components/FormIMC.js'; // Importa o componente FormularioIMC

export default function App() {
  return (
    <View style={styles.contêiner}>
      <Titulo />
      <FormularioIMC />
    </View>
  );
}

// Estilos do componente principal
const styles = StyleSheet.create({
  contêiner: {
    flex: 1, // Ocupa todo o espaço disponível
    backgroundColor: '#fff', // Fundo branco
    padding: 16, // Espaçamento interno
    justifyContent: 'center', // Centraliza os elementos verticalmente
  },
});