import React from 'react';
import { Text, StyleSheet } from 'react-native';

const Result = ({ imc }) => {
    return(
        <Text style={styles.result}>Seu IMC é: {imc}</Text> // Exibe o valor do IMC
    );
};

// Estilos do resultado
const styles = StyleSheet.create({
    result: {
        marginTop: 20, // Espaço acima
        fontSize: 24, // Tamanho da fonte
        textAlign: 'center', // Centralizado
        color: '#666', // Cor do texto
    },
});

export default Result;