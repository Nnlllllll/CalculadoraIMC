import React from 'react';
import { Text, StyleSheet } from 'react-native';

const PesoIdeal = ({ height }) => {
  // Validação de altura
  if (!height || height <= 0) return null; // Não renderiza se altura for inválida
  
  // Converte altura para metros
  const heightInMeters = height > 3 ? height / 100 : height;
  
  // Calcula peso ideal mínimo e máximo com base no IMC (18.5 a 24.9)
  const minWeight = (18.5 * heightInMeters * heightInMeters).toFixed(1);
  const maxWeight = (24.9 * heightInMeters * heightInMeters).toFixed(1);

  return (
    <>
      <Text style={styles.weightText}>
        Peso ideal mínimo: {minWeight} kg 
      </Text>
      <Text style={styles.weightText}>
        Peso ideal máximo: {maxWeight} kg 
      </Text>
    </>
  );
};

// Estilos do texto
const styles = StyleSheet.create({
  weightText: {
    fontSize: 16, // Tamanho da fonte
    textAlign: 'center', // Centralizado
    color: '#666', // Cor do texto
    marginTop: 8, // Espaço acima
  },
});

export default PesoIdeal;