import React from 'react';
import { Text, StyleSheet } from 'react-native';

const Classificação = ({ imc }) => {
  // Determina a classificação com base no IMC
  const getClassification = (imc) => {
    if (imc < 18.5) return 'Abaixo do peso';
    if (imc >= 18.5 && imc <= 24.9) return 'Peso normal';
    if (imc >= 25 && imc <= 29.9) return 'Sobrepeso';
    if (imc >= 30 && imc <= 34.9) return 'Obesidade grau 1';
    if (imc >= 35 && imc <= 39.9) return 'Obesidade grau 2';
    return 'Obesidade grau 3 (mórbida)';
  };

  // Define a cor do texto com base na classificação
  const getClassificationStyle = (imc) => {
    if (imc < 18.5) return { color: '#3498db' }; // Azul
    if (imc <= 24.9) return { color: '#2ecc71' }; // Verde
    if (imc <= 29.9) return { color: '#f39c12' }; // Amarelo
    return { color: '#e74c3c' }; // Vermelho
  };

  return (
    <Text style={[styles.classification, getClassificationStyle(imc)]}>
      Classificação: {getClassification(imc)} 
    </Text>
  );
};

// Estilos básicos da classificação
const styles = StyleSheet.create({
  classification: {
    fontSize: 18, // Tamanho da fonte
    textAlign: 'center', // Centralizado
    marginTop: 10, // Espaço acima
  },
});

export default Classificação;