import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text } from 'react-native';
import Result from './Result';
import Classificação from './Classificação';
import PesoIdeal from './PesoIdeal';

const FormIMC = () => {
  const [weight, setWeight] = useState(''); // Estado para o peso
  const [height, setHeight] = useState(''); // Estado para a altura
  const [imc, setImc] = useState(null); // Estado para o IMC
  const [errorMessage, setErrorMessage] = useState(''); // Estado para a mensagem de erro

  const calculateIMC = () => {
    console.log('Botão pressionado'); // Confirma que o botão foi clicado
    console.log('Peso:', weight, 'Altura:', height); // Mostra os valores atuais

    // Limpa a mensagem de erro inicialmente
    setErrorMessage('');
    console.log('Mensagem de erro limpa');

    // Verifica se os campos estão vazios
    if (!weight || !height) {
      setErrorMessage('Preencha todos os campos!');
      console.log('Erro: Campos vazios');
      return;
    }

    // Converte as entradas para números
    const weightNum = parseFloat(weight.replace(',', '.'));
    const heightNum = parseFloat(height.replace(',', '.'));

    console.log('Peso convertido:', weightNum, 'Altura convertida:', heightNum);

    // Valida o peso
    if (isNaN(weightNum)) {
      setErrorMessage('Peso deve ser um número válido!');
      console.log('Erro: Peso inválido');
      return;
    }

    // Valida a altura
    if (isNaN(heightNum)) {
      setErrorMessage('Altura deve ser um número válido!');
      console.log('Erro: Altura inválida');
      return;
    }

    // Valida valores maiores que zero
    if (weightNum <= 0 || heightNum <= 0) {
      setErrorMessage('Valores devem ser maiores que zero!');
      console.log('Erro: Valores <= 0');
      return;
    }

    // Valida limites superiores
    if (weightNum > 500) {
      setErrorMessage('Peso deve ser menor que 500 kg!');
      console.log('Erro: Peso > 500');
      return;
    }
    if (heightNum > 300) {
      setErrorMessage('Altura deve ser menor que 300 cm!');
      console.log('Erro: Altura > 300');
      return;
    }

    // Calcula o IMC
    const heightInMeters = heightNum > 3 ? heightNum / 100 : heightNum;
    const calculatedImc = (weightNum / (heightInMeters * heightInMeters)).toFixed(1);

    console.log('IMC calculado:', calculatedImc);
    setImc(calculatedImc); // Atualiza o IMC
    setErrorMessage(''); // Remove a mensagem de erro
    console.log('Cálculo concluído, erro removido');
  };

  // Aqui é onde o return deve ser colocado
  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Peso (kg)"
        keyboardType="numeric"
        value={weight}
        onChangeText={setWeight}
      />
      <TextInput
        style={styles.input}
        placeholder="Altura (cm)"
        keyboardType="numeric"
        value={height}
        onChangeText={setHeight}
      />
      <Button 
        title="Calcular IMC" 
        onPress={calculateIMC} 
        testID="calculateButton" 
      />
      
      {/* Sempre exibe o errorMessage, mesmo vazio */}
      <Text style={styles.errorText}>{errorMessage || ' '}</Text>

      {imc !== null && (
        <View style={styles.resultsContainer}>
          <Result imc={imc} />
          <Classificação imc={parseFloat(imc)} />
          <PesoIdeal height={parseFloat(height)} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  resultsContainer: {
    marginTop: 20,
  },
  errorText: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
});

export default FormIMC;