import { StyleSheet, Text, View } from 'react-native';
import Title from './src/components/Title.js'; // Importa o componente Title
import FormIMC from './src/components/FormIMC.js'; // Importa o componente FormIMC

export default function App() {
  return (
    <View style={styles.container}>
      <Title /> {/* Renderiza o título da calculadora */}
      <FormIMC /> {/* Renderiza o formulário para cálculo do IMC */}
    </View>
  );
}

// Estilos do componente principal
const styles = StyleSheet.create({
  container: {
    flex: 1, // Ocupa todo o espaço disponível
    backgroundColor: '#fff', // Fundo branco
    padding: 16, // Espaçamento interno
    justifyContent: 'center', // Centraliza os elementos verticalmente
  },
});